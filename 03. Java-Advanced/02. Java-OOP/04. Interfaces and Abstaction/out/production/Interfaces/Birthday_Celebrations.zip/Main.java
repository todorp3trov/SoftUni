import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List<Citizen> citizens = new ArrayList<>();
    private static List<Pet> pets = new ArrayList<>();
    private static List<Robot> robots = new ArrayList<>();
    private static List<String> birthYears = new ArrayList<>();


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String action = scanner.nextLine();

        while (!action.equals("End")) {
            String[] splitter = action.split(" ");
            if (splitter[0].equals("Citizen")) {
                citizens.add(new Citizen(splitter[1], Integer.parseInt(splitter[2]), splitter[3], splitter[4]));
                birthYears.add(splitter[4]);
            } else if (splitter[0].equals("Robot")) {
                robots.add(new Robot(splitter[1], splitter[2]));
            } else if (splitter[0].equals("Pet")) {
                pets.add(new Pet(splitter[1], splitter[2]));
                birthYears.add(splitter[2]);
            }
            action = scanner.nextLine();
        }

        action = scanner.nextLine();

        for (int i = 0; i < birthYears.size(); i++) {
            if (birthYears.get(i).substring(6, 10).equals(action)) {
                System.out.println(birthYears.get(i));
            }
        }
    }
}
